import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.LinkedList;

/**
 * CS2 HW7
 * CustomHashTable.java
 * Purpose: A custom hash table that performs all operations standard to the ADT
 * 
 * @author grantschumacher
 * @version 1.0 10/30/17
 */
public class CustomHashTable{
	
	 private int htSize;
	 private LinkedList<HashTableObject>[] htArray;
	 private int collisions;
	 
	 /**
	  * Stores key and value of an object inside of the hash table
	  * @author grantschumacher
	  *
	  */
	public class HashTableObject{
		public String key;
		public String value;
	}
	
	/**
	 * Constructor for hash table that creates a hash table of size "size" and initializes all values with null
	 * @param size
	 */
	public CustomHashTable(int size){
		htArray = new LinkedList[size];
		htSize = size;
		//Set all values in htArray to null, this will help with collision handling
		
		for(int i = 0; i < size; i++){
			htArray[i] = null;
		}
		
	}
	
	/**
	 * Gets the HashTableObject of the entered key
	 * @param key
	 * @return
	 */
	private HashTableObject getObject(String key){
		if(key == null){ //If the key does not exist return null
			return null;
		}
		int index = Math.abs(key.hashCode() % htSize);
		LinkedList<HashTableObject> items = htArray[index];
		
		if(items == null){ //If linked list at key does not exist return null
			return null;
		}
		
		for(HashTableObject item : items){ //Look through the linked list at the given index for item
			if(item.key.equals(key)){ //If the item is found return it
				return item;
			}
		}
		return null; //If the item can't be found whatsoever return null
	}
	
	/**
	 * Gets the value of the HashTableObject of the given key
	 * @param key
	 * @return
	 */
	public String get(String key){
		HashTableObject item = getObject(key); //Find the object at the given key
		
		if(item == null){ //if the object does not exist or fails to be located return null
			return null; 
		}else{ //If we find the item, return its value
			return item.value;
		}
	}
	
	/**
	 * Puts item into hash table
	 * @param key
	 * @param value
	 */
	public void put(String key, String value){

		int index = Math.abs(key.hashCode() % htSize);
		LinkedList<HashTableObject> items = htArray[index];
		
		if(items == null){ //if the index is empty, create a new linked list and populate it with the data
			items = new LinkedList<HashTableObject>();
			
			HashTableObject item = new HashTableObject();
			item.key = key;
			item.value = value;
			
			items.add(item);
			
			htArray[index] = items;
			
		}else{ //If a collision occurs
			collisions++;
			for(HashTableObject item: items){ //Run through linked list to find correct location
				
				if(item.key.equals(key)){
					
					item.value = value;
					return;
					
				}
				
			}
			
			HashTableObject item = new HashTableObject();
			item.key = key;
			item.value = value;
			items.add(item); //Due to collision, add item at next available index of linked list
			
		}
		
		
	}
	
	/**
	 * Removes item with specified key from hash table
	 * @param key
	 */
	public void delete(String key){
		
		int index = key.hashCode() % htSize;
		LinkedList<HashTableObject> items = htArray[index]; //Find linked list at index
		
		if(items == null){ //If the index does not exist return
			return;
		}
		for(HashTableObject item : items){ //Iterate through linked list at index
			
			if(item.key.equals(key)){ //if the key we are looking for is found
				
				items.remove(item); //remove the item
				return; //Stop searching for the key
				
			}
		}
	}
	
	/**
	 * Prints all data in elements 0 through 5 to file
	 */
	public void printToFile(){
		
		try{
			
		BufferedWriter bw = new BufferedWriter(new FileWriter("HW7_out"));
		
		for(int i = 0; i < 6; i++){ //Print the indexes 0 through 5 
			
			if(htArray[i] != null){ // Make sure the linked list exists
				
			LinkedList<HashTableObject> items = htArray[i]; //Get the linked list at index i
			
			bw.write("Index: "+ i ); //Write the index to the file
			
			for(int x = 0; x < items.size(); x++){ //Run through the linked list at index i 
				
				bw.write(" " + items.get(x).value); //Print each item value at linked list index x of array index i to the file
				
				
			}
			
			
			bw.newLine(); //Move to next line
			
			}else{ //If the list doesn't exist (This keeps the whole thing from blowing up when it gets a null value)
				
				bw.write("Index: " + i); //Write null to the file
				bw.newLine();
			}
			
		}
		
		bw.close();
		
		}catch(Exception ex){ 
			
			System.out.println("--Error writing to HW7.out--");
			
		}
	}
	
	public int getCollisions(){
		return collisions;
	}
	
}