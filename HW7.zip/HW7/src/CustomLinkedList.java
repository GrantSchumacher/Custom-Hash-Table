
public class CustomLinkedList{
		private Node head;
		private int listCount;
		
		/**
		 * No argument Constructor
		 */
		public CustomLinkedList(){
			head = new Node(null);
			listCount = 0;
		}
		
		/**
		 * Appends the Object data to the linked list
		 * @param data
		 */
		public void add(Object data){
			Node temp = new Node(data);
			Node current = head;
			
			while(current.getNext() != null){
				current = current.getNext();
			}
			
			current.setNext(temp);
			listCount++;
		}
		
		/**
		 * returns the size of the linked list
		 * @return
		 */
		public int size(){
			return listCount;
		}
		
		/**
		 * gets and returns object at specified index in linked list
		 * @param index
		 * @return
		 */
		public Object get(int index){
			if(index <= 0){
				return null;
			}
			Node current = head.getNext();
			
			for(int i = 1; i < index; i++){
				if(current.getNext() == null){
					return null;
				}
				current = current.getNext();
			}
			return current.getData();
		}
	}
	
	/**
	 * Node class to be implemented by LinkedList
	 * @author grantschumacher
	 *
	 */
	class Node{
		Node next;
		Object data;
		
		/**
		 * No argument contstructor
		 * @param data
		 */
		public Node(Object data){
			this.data = data;
			next = null;
		}
		
		/**
		 * Constructor for Node class
		 * @param data
		 * @param next
		 */
		public Node(Object data, Node next){
			this.next = next;
			this.data = data;
		}
		
		/**
		 * Gets object at specified node
		 * @return
		 */
		public Object getData(){
			return data;
		}
		
		/**
		 * Sets object at specified Node
		 * @param data
		 */
		public void setData(Object data){
			this.data = data;
		}
		
		/**
		 * Gets location of next node
		 * @return
		 */
		public Node getNext(){
			return next;
		}
		
		/**
		 * Sets location of next node
		 * @param next
		 */
		public void setNext(Node next){
			this.next = next;
		}
	}
	
