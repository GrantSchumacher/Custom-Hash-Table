import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Scanner;

/**
 * CS2 HW7
 * HW7.java
 * Purpose: Takes in a text file, counts unique words, generates customHashTable and java hash table based off of data, and prints elements 0 through 5 of 
 * 			each to file
 * @author grantschumacher
 * @version 1.0 10/30/17
 */
public class HW7 {
	private int uniqueWordCount;
	private int numberOfSlots;
	
	/**
	 * The main method
	 * @param args
	 */
	public static void main(String[] args) {
		HW7 h = new HW7();
		h.askForFile();
	}
	
	/**
	 * Asks the user for the file to analyze and put into hash table
	 */
	public void askForFile() {
		Scanner sc = new Scanner(System.in);
		String fileName;
		System.out.print("Enter the name of the file: ");
		fileName = sc.next();
		System.out.print("Enter a prime number for the size of the array: ");
		numberOfSlots = getPrime(Integer.parseInt(sc.next()));
		readFile(fileName);
		System.out.println("Number of slots: " + numberOfSlots);
		sc.close();
	}

	/**
	 * Reads in a specified file and converts it into a string array list with
	 * each index being one word from the file, excludes special characters
	 * 
	 * @param fileName
	 * @return
	 */
	public void readFile(String fileName) {
		String word;
		String firstWord;
		String secondWord;
		
		ArrayList<String> words = new ArrayList<String>();

		try {
			
			File file = new File(fileName);
			Scanner inputFile = new Scanner(file);
			
			while (inputFile.hasNext()) { //read file until end of text
				
				word = inputFile.next(); //read each word
				word = word.toLowerCase(); //Make all words lower case
				
				if(word.contains("--")){ // I was getting some issues with words being added together because the regex kicked out the -- and -
										// This lets me substring the words and add them separately to the array, making it more accurate 
					firstWord = word.substring(0, word.indexOf("--"));
					secondWord = word.substring(word.indexOf("--") + 2, word.length());
					firstWord = firstWord.replaceAll("[^a-zA-Z0-9']",""); 
					secondWord = secondWord.replaceAll("[^a-zA-Z0-9']",""); 
					words.add(firstWord);
					words.add(secondWord);
					
				}else if(word.contains("-")){
					
					firstWord = word.substring(0, word.indexOf("-"));
					secondWord = word.substring(word.indexOf("-") + 1, word.length());
					firstWord = firstWord.replaceAll("[^a-zA-Z0-9']",""); 
					secondWord = secondWord.replaceAll("[^a-zA-Z0-9']",""); 
					words.add(firstWord);
					words.add(secondWord);
					
				}else{
					
					word = word.replaceAll("[^a-zA-Z0-9']",""); //Remove special characters excluding apostrophe
					words.add(word);
					
				}
				
			}

			inputFile.close();
			Collections.sort(words); //Sort the word array to count unique words and remove non-unique words
			createHashTable(getUniqueWords(words), numberOfSlots); //Create custom hash table with uniqueWordCount being the number of elements and .75 load factor
			
		} catch (Exception ex) { 
			System.out.println(ex);
			ex.printStackTrace(System.out);
			System.out.println("--Error finding file. Try again.--");
			askForFile();
		}

	}

	/**
	 * Gets the unique words from a sorted array of words
	 * @param list
	 * @return
	 */
	private ArrayList<String> getUniqueWords(ArrayList<String> list) {
		
		ArrayList<String> uniqueWords = new ArrayList<String>();
		
		for (int i = 0; i < list.size() - 1; i++) {
			
			if (list.get(i).equals(list.get(i + 1)) == false) {
				
				uniqueWords.add(list.get(i));
				uniqueWordCount++;
				
			}
			
		}
		
		System.out.println("Unique words: " +uniqueWordCount);
		
		return uniqueWords;
	}
	
	/**
	 * Creates a custom hash table and a java hash table of the ArrayList "list" and then prints those tables to individual files
	 * @param list
	 * @param elm
	 * @param lf
	 */
	private void createHashTable(ArrayList<String> list, int slots){
		
		int numberOfSlots = slots;
		
		CustomHashTable customHashTable = new CustomHashTable(numberOfSlots); //Create a hash table the size of the number of unique words
		Hashtable<String, String> hashTable = new Hashtable<String, String>(numberOfSlots); //Create a java hash table of the same size as my customHashTable that defaults to a load factor of .75
		
		for(int i = 0; i < list.size(); i++){ //Populate hash tables
			
			customHashTable.put(list.get(i), list.get(i)); //Populate custom hash table
			hashTable.put(list.get(i), list.get(i)); //Populate java hash table
			
		}
		
		System.out.println("Number of collisions: " +customHashTable.getCollisions());
		customHashTable.printToFile(); //Print the contents of the custom hash table to file HW7.out
		
		try{
			BufferedWriter bw = new BufferedWriter(new FileWriter("HW7_hash"));
			
			Enumeration<String> keys = hashTable.keys(); //Get enumeration of keys
			
			for(int x = 0; x < 6; x++){ //Print keys 0 through 5 to file HW7_hash
				
				String key = keys.nextElement();
				bw.write("Key " + x + " " +hashTable.get(key));
				bw.newLine();
				
			}
			
			bw.close();
			
		}catch(Exception ex){
			
			System.out.println("--Error writing to HW7.hash--");
			
		}
	}
	
	/**
	 * ---EXTRA CREDIT---
	 * If number is prime it returns the number. If number is not prime it converts it to prime and returns that number
	 * @param number
	 * @return
	 */
	public int getPrime(int number) {
		System.out.println("----------------------------------------------------------------"); //Just make it look good 
		boolean prime = prime(number);
		
		if (prime == true) { //If the number is prime tell the user and return the number
			
			System.out.print("The number you entered is prime. The size of the array will be: "); 
			
		} else { //If the number is not prime tell the user, make it prime, then return the number
			
			System.out.print("The number you entered is not prime. The size has been defaulted to the next nearest prime which is: ");
			
			while (prime == false) {
				number++;
				prime = prime(number);
			}
			
		}
		
		System.out.println(number);
		System.out.println("----------------------------------------------------------------");
		
		return number;
	}
	
	/**
	 * Checks whether or not number is prime. Returns true if prime, false if not prime
	 * @param number
	 * @return
	 */
	private boolean prime(int number){
		for(int i = 2; i <= (number / 2); i++){
			if(number % i == 0){
				return false;
			}
		}
		return true;
	}

}
